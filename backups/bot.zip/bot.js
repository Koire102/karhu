/* BOT INFO*/
console.log('');
console.log('  SUOMI-BOT');
console.log('  by boi#3136');
console.log('');

/* LIBRARIES */
const Discord = require('discord.js');
const client = new Discord.Client();
var fs = require('fs');
var request = require('request');
var iconv = require('iconv-lite');
var colors = require('colors');
console.log('[LIBRARIES]'.green + ' Ready');


/* VARIABLES */
var oracle = true;
const token = 'Mzg3NjE0NzEyNTk2MTM1OTM2.DQ1jNQ.qvFYsgrkjFiTxBYKkabfvuZhqF4';
var lines = '';
var lineslength = 0;
var flines = '';
var flineslength = 0;
var s_hei = ['moi', 'mui', 'hai', 'terve', 'tere', 'tervehdys', 'moikkelis koikkelis', 'hej', 'hejsan', 'tere tere', 'heyyyyy', 'moro', 'niao', 'zau', 'tsau', 'heippa', 'heipsis', 'morjens', 'hola', 'hei', 'heissan', 'heips', 'helou'];
var s_time = new Date();
var s_ts = addLeadingZero(s_time.getDate().toString()) + '.' + addLeadingZero(s_time.getMonth().toString()) + '.' + s_time.getFullYear().toString() + ' ' + addLeadingZero(s_time.getHours().toString()) + ':' + addLeadingZero(s_time.getMinutes().toString());
console.log('[VARIABLES]'.green + ' Ready');

/* FUNCTIONS */
function addLeadingZero(n){ return n < 10 ? '0'+n : ''+n }
console.log('[FUNCTIONS]'.green + ' Ready');


/* OTHER */
fs.readFile('quotes.txt', function(err, data){
    if(err) throw err;
	data += '';
    lines = data.split('\n');
	lineslength = lines.length;
	
	console.log('[OTHER]    '.green + ' Quotes loaded (' + lineslength + ' rows)');
});
fs.readFile('facts.txt', function(err, data){ 
	if(err) throw err;
	data += '';
    flines = data.split('\n');
	flineslength = flines.length;
	
	console.log('[OTHER]    '.green + ' Facts loaded (' + flineslength + ' rows)');
});


/* CLIENT */
client.on('ready', () => {
	console.log('[CLIENT]   '.green + ' Ready');
});

client.on('message', message => {
	if (message.content.substring(0, 2).trim() == 's!') {
		var args = message.content.substring(2).split(' ');
		var cmd = args[0];

		args = args.splice(1);
		
		console.log('[MESSAGE]  '.yellow + ' ' + message.author.tag + ' (' + message.author.id + '): ');
		console.log('            '.yellow + message.content);
		
		/* BOT COMMANDS */
		switch (cmd) {
			case 'sananlasku':
				if (args.length > 0) {
					if (args[0] < 1896) {
						if (args[0] >= 0) {
							message.channel.send({
								embed: {
									color: 2208672,
									title: lines[args[0]],
									footer: {
										text: 'Suomalainen sananlasku #' + args[0].toString()
									}
								}
							});
						}
					}
				} else {
					var rnln = Math.floor(Math.random() * lineslength);
					message.channel.send({
						embed: {
							color: 2208672,
							title: lines[rnln],
							footer: {
								text: 'Suomalainen sananlasku #' + rnln.toString()
							}

						}
					});
				}
				break;
				
			case 'fakta':
				if (args.length > 0) {
					if (args[0] < 32) {
						if (args[0] >= 0) {
							message.channel.send({
								embed: {
									color: 16392795,
									title: flines[args[0]],
									footer: {
										text: 'Suomalainen fakta #' + args[0].toString()
									}
								}
							});
						}
					}
				} else {
					var rnln = Math.floor(Math.random() * flineslength);
					message.channel.send({
						embed: {

							color: 16392795,
							title: flines[rnln],
							footer: {
								text: 'Suomalainen fakta #' + rnln.toString()
							}
						}
					});
				}
				break;
				
			case 'apua':
				message.channel.send(':information_source: https://suomi-bot.4d48.tk/');
				break;
				
			case 'info':
				message.channel.send(':information_source: suomi-bot on ollut päällä ' + s_ts.toString() + ' lähtien');
				break;
				
			case 'moi':
				if (args.length > 0) {
					if (args[0].indexOf('@') !== -1) {
						message.delete();
						message.channel.send(s_hei[Math.floor(Math.random()*s_hei.length)] + ' ' + args[0]);
					}
				}
				break;
			case 'oraakkeli':
				if (args.length > 0) {
					if (args[0].length < 70) { /* question must be below 70 characters */
						var kysymysa = message.content.substring(12);
						var kysymys = encodeURI(kysymysa.replace(" ", "+"));

						if (oracle == true) { /* cooldown */
							oracle = false;
							setTimeout(function() {
								oracle = true;
							}, 5000);
							request.get({
									uri: 'http://www.lintukoto.net/viihde/oraakkeli/index.php?kysymys=' + kysymys + '&html',
									encoding: null
								},
								function(err, resp, body) {
									var bodyWithCorrectEncoding = iconv.decode(body, 'iso-8859-1');
									var vastaus = bodyWithCorrectEncoding.trim();
									if (vastaus.length < 250) {
										message.channel.send({
											embed: {
												color: 16709372,
												title: kysymysa,
												description: vastaus,
												footer: {
													text: 'lintukoto.net - oraakkeli'
												},
												url: 'http://www.lintukoto.net/viihde/oraakkeli/index.php?kysymys=' + kysymys
											}
										});
									} else {
										message.reply(':x: Virhe 196');
									}
								}
							);
						} else {
							message.channel.send(':hourglass: Oraakkelin on jäähdyttävä viitisen sekuntia');
						}
					} else {
						message.channel.send(':x: Virhe 204');
					}
				}
				break;
		}
	}
});


client.login(token);